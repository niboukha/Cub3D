/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cast_rays.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niboukha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/17 09:52:32 by niboukha          #+#    #+#             */
/*   Updated: 2023/10/06 11:33:22 by niboukha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

void	fill_map3(t_map *map)
{
	int	i;
	int	j;

	i = 0;
	while (i < W_WIN)
	{
		j = 0;
		while (j < H_WIN)
		{
			my_mlx_put_pixel(&map->image, i, j, 0x000000);
			j++;
		}
		i++;
	}
}

unsigned int	rgb_to_hex(int r, int g, int b)
{
	return ((r & 0xff) << 16) + ((g & 0xff) << 8) + (b & 0xff);
}

void	draw_walls(t_map *map, int color, double angle)
{
	int	j;
	int	start;
	int	end;
	int	f_color;
	int	c_color;

	printf("%d\n", map->data->c_c->f->r);
	f_color = rgb_to_hex(map->data->c_c->f->r, map->data->c_c->f->g, map->data->c_c->f->b);
	c_color = rgb_to_hex(map->data->c_c->c->r, map->data->c_c->c->g, map->data->c_c->c->b);
	map->wall.wall_height = ceil(64 *
		W_WIN / (fabs(2 * tan(M_PI / 6) * (map->coor.d * cos(angle - map->coor.angle)))));
	start = (H_WIN / 2) - (map->wall.wall_height / 2);
	end = (H_WIN / 2) + (map->wall.wall_height / 2);
	if (start < 0)
		start = 0;
	j = 0;
	while (j < H_WIN)
	{
		if (j <= start)
			my_mlx_put_pixel(&map->image, map->wall.x, map->wall.y + j,f_color);
		if (j > start && j <= end)
			my_mlx_put_pixel(&map->image, map->wall.x, map->wall.y + j, color);
		if (j > end)
			my_mlx_put_pixel(&map->image, map->wall.x, map->wall.y + j, c_color);
		j++;
	}
}
