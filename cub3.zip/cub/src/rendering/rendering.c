/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rendering.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niboukha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/08 15:19:31 by niboukha          #+#    #+#             */
/*   Updated: 2023/10/07 21:13:56 by niboukha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

void	init_image(t_map *map)
{
	int	w_img;
	int	h_img;

	map->sprit.img_d[0] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr1.xpm", &w_img, &h_img);
	map->sprit.img_d[1] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr3.xpm", &w_img, &h_img);
	map->sprit.img_d[2] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr5.xpm", &w_img, &h_img);
	map->sprit.img_d[3] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr7.xpm", &w_img, &h_img);
	map->sprit.img_d[4] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr8.xpm", &w_img, &h_img);
	map->sprit.img_d[5] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr10.xpm", &w_img, &h_img);
	map->sprit.img_d[6] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr11.xpm", &w_img, &h_img);
	map->sprit.img_d[7] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr13.xpm", &w_img, &h_img);
	map->sprit.img_d[8] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr15.xpm", &w_img, &h_img);
	map->sprit.img_d[9] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr17.xpm", &w_img, &h_img);
	map->sprit.img_d[10] = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/anmt/dr19.xpm", &w_img, &h_img);
}

void	init_mlx(t_map *map)
{
	int	w_img;
	int	h_img;

	map->mlx = mlx_init();
	map->mlx_win = mlx_new_window(map->mlx, W_WIN, H_WIN,
			"cub3d");
	map->image.img = mlx_new_image(map->mlx, W_WIN, H_WIN);
	map->image.addr = mlx_get_data_addr(map->image.img,
			&map->image.bits_per_pixel, &map->image.line_length,
			&map->image.endian);
	map->textures.img_w = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/we.xpm", &w_img, &h_img);
	map->textures.img_e = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/skull.xpm",
			&w_img, &h_img);
	map->textures.img_s = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/so.xpm",
			&w_img, &h_img);
	map->textures.img_n = mlx_xpm_file_to_image(map->mlx,
			"/nfs/homes/niboukha/Desktop/cub/textures/no.xpm",
			&w_img, &h_img);
	init_image(map);
}

void	rendering(t_map	*map)
{
	init_map(map);
	init_mlx(map);
	put_pixel(map);
	mlx_hook(map->mlx_win, 2, 1L << 0, key, map);
	mlx_mouse_hook(map->mlx_win, mouse_key, map);
	mlx_loop_hook(map->mlx, animation, map);
	mlx_hook(map->mlx_win, 17, 1L << 0, close_win, map);
	mlx_loop(map->mlx);
}
