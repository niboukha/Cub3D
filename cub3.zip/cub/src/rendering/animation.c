/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   animation.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niboukha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/07 15:42:25 by niboukha          #+#    #+#             */
/*   Updated: 2023/10/07 21:56:29 by niboukha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

int	animation(t_map *map)
{
	map->sprt.timer++;
	if (map->sprt.timer >= 100)
		map->sprt.timer = 0;
	get_dist_wall(map);
	mlx_put_image_to_window(map->mlx, map->mlx_win, map->image.img, 0, 0);
	return (0);
}
